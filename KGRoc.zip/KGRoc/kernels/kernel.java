package sigir.kernels;

public abstract class kernel {  //abstract 修饰符，声明抽象类的唯一目的是为了将来对该类进行扩充。 
	//一个类不能同时被 abstract 和 final 修饰。如果一个类包含抽象方法，那么该类一定要声明为抽象类，否则将出现编译错误。
	
	public double sigma = 12.5;
	
	public void setParameter(double s){
		this.sigma = s;
	}
	
	public abstract String kernelname();
	
	public abstract double value(double distfromcenter);
	
	public double intersect(double distbetween){
		return value(distbetween/2);
	}
	
}