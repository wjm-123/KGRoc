package sigir;

import java.io.*;
import java.util.*;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.apache.lucene.benchmark.byTask.feeds.*;
import org.apache.lucene.benchmark.byTask.utils.*;
import org.apache.lucene.document.*;


public class IndexTREC {

	private IndexTREC() {
	}

	public static void main(String[] args) throws Exception {

		String usage = "java org.apache.lucene.demo.IndexFiles"
				+ " [-index INDEX_PATH] [-docs DOCS_PATH] [-update]\n\n"
				+ "This indexes the documents in DOCS_PATH, creating a Lucene index"
				+ "in INDEX_PATH that can be searched with SearchFiles";
		String indexPath = "index_AP90_529";          //索引名称要改
		String docsPath = "D:/JavaWorkSpace/index_IRRPF/DataSet/AP/DataSet_AP90";   //hh测试，所有文章词条存放目录
//		String docsPath = "F:/TREC_DATA/collection/AP/AP90";
//		String indexPath = "index_AP8889";
//		String docsPath = "F:/TREC_DATA/collection/AP/AP8889";
//		String indexPath = "index_disk12";
//		String docsPath = "F:/TREC_DATA/collection/disk12";
//		String indexPath = "index_disk45";
//		String docsPath = "F:/TREC_DATA/collection/disk45";
//		String indexPath = "index_wt2g";
//		String docsPath = "F:/TREC_DATA/collection/wt2g";
//		String indexPath = "index_wt10g";
//		String docsPath = "F:/TREC_DATA/collection/wt10g";
//		String indexPath = "index_SJMN";
//		String docsPath = "F:/TREC_DATA/collection/disk3/SJMN";
//		String indexPath = "index_WSJ";
//		String docsPath = "F:/TREC_DATA/collection/disk12/WSJ";
//		String indexPath = "index_FBIS";
//		String docsPath = "F:/TREC_DATA/collection/disk45/FBIS";
//		String indexPath = "index_FT";
//		String docsPath = "F:/TREC_DATA/collection/disk45/FT";
//		String indexPath = "index_AP";
//		String docsPath = "F:/TREC_DATA/collection/AP";
//		String indexPath = "index_LA";
//		String docsPath = "F:/TREC_DATA/collection/disk45/LA";
	//	String indexPath = "index_GOV2";
	//	String docsPath = "F:/TREC_DATA/collection/GOV2";


		boolean create = true;
		for(int i=0;i<args.length;i++) {
			if ("-index".equals(args[i])) {
				indexPath = args[i+1];
				i++;
			} else if ("-docs".equals(args[i])) {
				docsPath = args[i+1];
				i++;
			} else if ("-update".equals(args[i])) {
				create = false;
			}
		}

		if (docsPath == null) {
			System.err.println("Usage: " + usage);
			System.exit(1);
		}

		final File docDir = new File(docsPath);
		if (!docDir.exists() || !docDir.canRead()) {
			System.out.println("Document directory '" +docDir.getAbsolutePath()+ "' does not exist or is not readable, please check the path");
			System.exit(1);
		}

		Date start = new Date();
		try {
			System.out.println("Indexing to directory '" + indexPath + "'...");
             //Store the index in memory:
			/*Directory dir = new RAMDirectory();*/
			//To store an index on disk, use this instead:
			Directory dir = FSDirectory.open(new File(indexPath));     //索引文件的保存位置
			//Analyzer analyzer = new StandardAnalyzer(Version.LUCENE_41);
			Analyzer analyzer = new MyStopAndStemmingAnalyzer();      //分析器      
			
			IndexWriterConfig iwc = new IndexWriterConfig(Version.LUCENE_41,analyzer);   //配置索引写入器的版本、分析器
			iwc.setOpenMode(OpenMode.CREATE);    //创建模式，默认是附加模式，会增加一遍索引，导致搜索时候搜索两遍，要手动定义成create模式，   OpenMode.CREATE_OR_APPEND 添加模式
			iwc.setRAMBufferSizeMB(1024.0);

			IndexWriter writer = new IndexWriter(dir, iwc);    //构建索引写入器

			TrecContentSource tcs = new TrecContentSource();    //抽出head到dead域中，抽出text到text域中，细致抽出标签，此处抽出content到content域中
			Properties props = new Properties();                 //
			props.setProperty("print.props", "false");
			props.setProperty("content.source.verbose", "false");
			props.setProperty("content.source.excludeIteration", "true");
			props.setProperty("doc.maker.forever", "false");
			props.setProperty("work.dir", ".");//要改
			props.setProperty("docs.dir", docsPath);// 要改
			props.setProperty("trec.doc.parser", sigir.myTrecParser.class.getName());
			props.setProperty("content.source.forever", "false");
			//hh+ 是不是得加一个编码的属性，TrecContentSource默认是"ISO-8859-1"
			tcs.setConfig(new Config(props));
			tcs.resetInputs();        //固定操作
			int n = 0;
			DocData dd = new DocData();   //
			while (true) {
				try {
					dd = tcs.getNextDocData(dd);
				} catch (NoMoreDataException e) {
					break;
				}

				Document doc = new Document();        //根据文件创建索引文档
				doc.add(new StringField("docno", dd.getName(), Field.Store.YES));   //将不同的域信息添加到索引文档中，从而构建索引文档，传入参数（域名称，文档文本内容，是否保存）
				//输出一下docno测试一下
				//System.out.print("ID: ");
				//System.out.println(dd.getID());
				System.out.print("Name: ");
				System.out.println(dd.getName());          //文档编号
				//System.out.println("Body: ");
				//System.out.println(dd.getBody());        //文档主体，包括<HEAD>，<TEXT>之类的
				
				FieldType textWithTermVectors = new FieldType(TextField.TYPE_STORED);   //设置属性是否存储，是否索引，是否存储分词
				textWithTermVectors.setIndexed(true);
				textWithTermVectors.setStoreTermVectors(true);

				doc.add(new Field("contents", dd.getBody(), textWithTermVectors));    //将不同的域信息添加到索引文档中，从而构建索引文档。建立文档doc的docno域，就是一列属性
				//doc.add(new Field("head", dd.getTitle(), textWithTermVectors));

				if(writeProcessedDocsToFile(analyzer, dd.getBody())){

					writer.addDocument(doc);       //添加所有的索引文档添加到索引库中
					n++;
					
					System.out.println(n);
				}
			}

			writer.forceMerge(1);
			writer.close();
			tcs.close();
			Date end = new Date();
			System.out.println(end.getTime() - start.getTime() + " total milliseconds");
		}catch (IOException e) {
			System.out.println(" caught a " + e.getClass() +
					"\n with message: " + e.getMessage());
		}
	}

	/**
	 * 
	 * @param writer			
	 * @param analyzer		
	 * @param text			
	 * @throws IOException
	 */
	public static boolean writeProcessedDocsToFile(Analyzer analyzer, String text) throws IOException {

		ArrayList<String> terms = MyStopAndStemmingAnalyzer.getTermList(analyzer, text);
		if (terms.size() == 0) {
			//writer.write("\r\n");

			return false;
		}
		return true;
	}
}