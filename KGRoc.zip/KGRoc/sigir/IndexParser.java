package sigir;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.benchmark.byTask.feeds.DocData;
import org.apache.lucene.benchmark.byTask.feeds.NoMoreDataException;
import org.apache.lucene.benchmark.byTask.feeds.TrecContentSource;
import org.apache.lucene.benchmark.byTask.utils.Config;
import org.apache.lucene.document.*;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.*;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;

public class IndexParser {
    private static String usage = "java org.apache.lucene.demo.IndexFiles"
            + " [-index INDEX_PATH] [-docs DOCS_PATH] [-update]\n\n"
            + "This indexes the documents in DOCS_PATH, creating a Lucene index"
            + "in INDEX_PATH that can be searched with SearchFiles";
//    private static String indexPath = "index418_wt2g";
    private static String docsPath = "E:/Lucene检索框架/TREC_DATA/dataset/DataSet_WT2G";   //hh测试
    private static String htmlContent = "content";
    private static String fileName = my_ROC1_test.dataName+"htmlContent.json";

    public static void main(String[] args) throws Exception {
        List<String> data = new ArrayList<>();
        data.add("AAAAAAAAAAAAA");
        data.add("AAAAAAAAAAAAA2");

        writeTxt(docsPath, data, "htmlContent.json", false, "");

//		String docsPath = "F:/TREC_DATA/collection/AP/AP90";
//		String indexPath = "index_AP8889";
//		String docsPath = "F:/TREC_DATA/collection/AP/AP8889";
//		String indexPath = "index_disk12";
//		String docsPath = "F:/TREC_DATA/collection/disk12";
//		String indexPath = "index_disk45";
//		String docsPath = "F:/TREC_DATA/collection/disk45";
//		String indexPath = "index_wt2g";
//		String docsPath = "F:/TREC_DATA/collection/wt2g";
//		String indexPath = "index_wt10g";
//		String docsPath = "F:/TREC_DATA/collection/wt10g";
//		String indexPath = "index_SJMN";
//		String docsPath = "F:/TREC_DATA/collection/disk3/SJMN";
//		String indexPath = "index_WSJ";
//		String docsPath = "F:/TREC_DATA/collection/disk12/WSJ";
//		String indexPath = "index_FBIS";
//		String docsPath = "F:/TREC_DATA/collection/disk45/FBIS";
//		String indexPath = "index_FT";
//		String docsPath = "F:/TREC_DATA/collection/disk45/FT";
//		String indexPath = "index_AP";
//		String docsPath = "F:/TREC_DATA/collection/AP";
//		String indexPath = "index_LA";
//		String docsPath = "F:/TREC_DATA/collection/disk45/LA";
        //	String indexPath = "index_GOV2";
        //	String docsPath = "F:/TREC_DATA/collection/GOV2";

//        generateMethod();
    }

    /**
     * 输出html文档内容
     */
    public void generateMethod(String docsPath, Map<String, TreeMap<String,String>> contents) {
        final File docDir = new File(docsPath);
        if (!docDir.exists() || !docDir.canRead()) {
            System.out.println("Document directory '" +docDir.getAbsolutePath()+ "' does not exist or is not readable, please check the path");
            System.exit(1);
        }

        Date start = new Date();
        try {
            System.out.println("Indexing418 to directory '"  + "'...");

//            Directory dir = FSDirectory.open(new File(indexPath));
//            System.out.println(((FSDirectory) dir).getDirectory().getPath());
            //Analyzer analyzer = new StandardAnalyzer(Version.LUCENE_41);
            Analyzer analyzer = new MyStopAndStemmingAnalyzer();

//            IndexWriter writer = new IndexWriter(dir, iwc);

            TrecContentSource tcs = new TrecContentSource();
            Properties props = new Properties();
            props.setProperty("print.props", "false");
            props.setProperty("content.source.verbose", "false");
            props.setProperty("content.source.excludeIteration", "true");
            props.setProperty("doc.maker.forever", "false");
            props.setProperty("work.dir", ".");//
            props.setProperty("docs.dir", docsPath);//
            props.setProperty("trec.doc.parser", myTrecParser.class.getName());
            props.setProperty("content.source.forever", "false");
            //hh+ 是不是得加一个编码的属性，TrecContentSource默认是"ISO-8859-1"
            tcs.setConfig(new Config(props));
            tcs.resetInputs();
            int n = 0;
            int j = 0;
            DocData dd = new DocData();
            while (true) {
                try {
                    dd = tcs.getNextDocData(dd);
                } catch (NoMoreDataException e) {
                    break;
                }
                Document doc = new Document();
                doc.add(new StringField("docno", dd.getName(), Field.Store.YES));
                //输出一下docno测试一下
                //System.out.print("ID: ");
                //System.err.println(dd.getID());
                //System.out.print("Name: ");
                //System.out.println(dd.getName());          //文档编号
                //System.out.println("Body: ");
                //System.out.println(dd.getBody());        //文档主体，包括<HEAD>，<TEXT>之类的

                FieldType textWithTermVectors = new FieldType(TextField.TYPE_STORED);
                textWithTermVectors.setIndexed(true);
                textWithTermVectors.setStoreTermVectors(true);

                doc.add(new Field("contents", dd.getBody(), textWithTermVectors));
                j++;
                if(writeProcessedDocsToFile(analyzer, dd.getBody())){
                    n++;
                    System.out.println(n);
//                    if(n==1)
//                    {
//                        System.out.println(dd.getName());
//                        System.out.println(dd.getBody());
//                    }
                    Set<String> tis = contents.keySet();
                    for (String key : tis) {
                        Map<String, String> queryContent = contents.get(key);
                        for (java.lang.String it : queryContent.keySet()) {
                            if ("491729".equals(n)) {
                                System.out.println("body is : "+dd.getBody());
                                System.out.println("name is : "+dd.getName());
                                System.out.println("date is : "+dd.getDate());
                                System.out.println("title is : "+dd.getTitle());
                                System.out.println("ID is : "+dd.getID());
                                System.out.println("props is : "+dd.getProps().toString());
                            }
                            if (it.equals("" + n)) {
                                String body = dd.getBody().replaceAll("\n", " ").replaceAll("\t", " ");
                                queryContent.put("" + n, body);
                            }
                        }
                    }
                }
            }
            System.out.println("n is : "+n);
            System.out.println("j is : "+j);
            String content = extractContent(contents);
            List<String> outContents = new ArrayList<>();
            outContents.add(content);
            writeTxt(htmlContent, outContents, fileName, true, "" );
//            writer.forceMerge(1);
//            writer.close();
            tcs.close();
            Date end = new Date();
            System.out.println(end.getTime() - start.getTime() + " total milliseconds");
        }catch (IOException e) {
            System.out.println(" caught a " + e.getClass() +
                    "\n with message: " + e.getMessage());
        }
    }

    /**
     *  保存数据
     * @param contents
     * @return
     */
    public String extractContent(Map<String, TreeMap<String, String>> contents) {
        JSONArray jsonArrayOri = new JSONArray();
        Set<Map.Entry<String, TreeMap<String, String>>> entries = contents.entrySet();
        for (Map.Entry<String, TreeMap<String, String>> entry: entries) {
            String query = entry.getKey();
            JSONArray jsonArray = new JSONArray();
            Set<Map.Entry<String, String>> subEntry = entry.getValue().entrySet();
            for (Map.Entry<String, String> kvs : subEntry) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("articleId", kvs.getKey());
                jsonObject.put("content", kvs.getValue());
                jsonArray.put(jsonObject);
            }
            JSONObject jsonObjectOri = new JSONObject();
            jsonObjectOri.put("query", query);
            jsonObjectOri.put("article_list", jsonArray);
            jsonArrayOri.put(jsonObjectOri);
        }
        return jsonArrayOri.toString();
    }

    /**
     *
     * @param analyzer
     * @param text
     * @throws IOException
     */
    public static boolean writeProcessedDocsToFile(Analyzer analyzer, String text) throws IOException {

        ArrayList<String> terms = MyStopAndStemmingAnalyzer.getTermList(analyzer, text);
        if (terms.size() == 0) {
            //writer.write("\r\n");

            return false;
        }
        return true;
    }

    public static void writeTxt(String path, List<String> content, String name,  boolean deleteFlag ,String charset) throws IOException {
        File txt = new File(name);
        if (!txt.exists())
            txt.createNewFile();
        else if(deleteFlag)
            txt.delete();

        BufferedWriter fw = null;

        try {
            if(charset.isEmpty()){
                charset = "UTF-8";
            }else{

            }
            fw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(txt, true), charset)); // 指定编码格式，以免读取时中文字符异常

            for(String temp : content){
                if(!temp.equals("\n") && !temp.isEmpty()){
                    fw.append(temp);
                    fw.newLine();
                }
            }
            fw.flush(); //全部写入缓存中的内容
        } catch (Exception e) {
            e.printStackTrace();
        } finally {  
            if (fw != null) {
                try {
                    fw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
